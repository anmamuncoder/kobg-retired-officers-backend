from django.apps import AppConfig


class CourseConfig(AppConfig):
    name = 'apps.course'
